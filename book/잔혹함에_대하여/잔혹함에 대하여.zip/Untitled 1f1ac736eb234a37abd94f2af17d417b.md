# 잔혹함에 대하여

LET: May 09, 2020 11:25 PM
독서 여부: Reading
작가: 애덤 모턴
호감 정도: 🔥🔥

---

layout: post

title: "잔혹함에 대하"

subtitle: "악에 대한 성찰"

type: "Book Review"

blog: true

text: true

author: "YoSeb Choi"

post-header: true

header-img: "img/header.jpg"

order: 1

---

# 독서 계기

봄 독서회의 5월 첫번 째 도서로 정해져서 읽게되었다. 원래는 김연수 작가의 `네가 누구든 얼마나 외롭든`의 순서였는데, 코로나 때문에 얼어있던 토론분위기를 좀 녹이고자 좀 더 뜨거운 토론을 할 수 있는 책으로 우선 선정된 듯 하다.

E북으로는 나와있는 상품이 없어서(생각해보니 알라딘에만 검색해봤어서 다른 곳에는 ebook으로 나와있는지 찾아봤지만 역시 아무데도 없었다) 중고 종이책으로 오랜만에 책을 사게되었다.

# 줄거리

읽기 전이다.

# 감상평

읽기 전이다.